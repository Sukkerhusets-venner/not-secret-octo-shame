

Spring web application for spring project 2014.

See documentation for further details.